package TestPackages.dao;

public class VendingMachineDaoImplTest {
}
