package TestPackages.service;

public class VendingMachineAuditDaoStubImpl {
}
