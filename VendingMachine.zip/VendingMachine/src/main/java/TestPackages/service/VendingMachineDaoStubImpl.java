package TestPackages.service;

public class VendingMachineDaoStubImpl {
}
