package VendingMachineService;

public class VendingMachineInsufficentFundsException extends Throwable {
}
