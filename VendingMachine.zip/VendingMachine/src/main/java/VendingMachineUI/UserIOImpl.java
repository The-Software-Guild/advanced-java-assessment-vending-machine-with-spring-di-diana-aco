package VendingMachineUI;

public class UserIOImpl {
}
