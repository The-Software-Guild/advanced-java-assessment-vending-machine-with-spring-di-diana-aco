package VendingMachineDto;

// Declaring enum
public enum CoinValue {
    QUARTERS, DIMES, NICKELS, PENNIES
}
