package VendingMachineDao;public class VendingMachineAuditDaoImpl {
}
